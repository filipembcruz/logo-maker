<?php $__env->startSection('content'); ?>

<main-card title="Your results" subtitle="Click on the chosen logo to download a PNG file.<br>
    If you didn’t like any of the results, just click “Generate more”.">
</main-card>
<body-card colsm="8" colmd="8" css="min-height: 500px;">
    <logo-card url="<?php echo e(route('home')); ?>"></logo-card>

    <v-form class="mx-5 mt-6 px-2">
        <v-btn href="<?php echo e(route('home')); ?>" class="font-weight-medium px-5" color="#3F51B5" style="letter-spacing: 0.75px;" elevation=0 text>GO BACK</v-btn>
        <custom-btn>GENERATE MORE</custom-btn>
    </v-form>
</body-card>
<?php $__env->stopSection(); ?>

<style>
    @media  only screen and (min-width: 600px) {
        .form-welcome {
            padding: 1rem 5rem 2.5rem;
        }
    }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logo-maker\resources\views/results.blade.php ENDPATH**/ ?>